/* $Id:os_cpu_c.c, v 1.0
 *
 * Description:
 *	uC/OS-II 80C52 - Processor Dependent Module
 *
 * Author[s]:
 *	Lucas Cruz Martos	<lcm@eresmas.net>
 *
 * Language:
 *	BSO-Tasking CC51 v5.0r2
 *
 * Reference:
 * 	MicroC/OS-II The Real-Time Kernel. Chapter 8     
 */
/*
 *                     INCLUDE FILES
 */
#include "includes.h"

#if !defined(_CC51)
#error This piece of code only works with BSO-Tasking CC51 V5.0r2
#endif

/*
 *
 *                    CREATE A TASK
 *
 */
OS_STK *OSTaskStkInit(void _regparm _reentrant (*task)(void *pd), void *pdato, OS_STK *ptos, INT16U opt)
{
OS_STK *stk;        
OS_STK *temp_sp;

    	opt = opt;

    	stk  = ptos;

// remember the stack grows downward 
	*stk     = ((INT16U)pdato & 0xFF);	/* Push data on xstack       	*/
	*--stk   = ((INT16U)pdato >> 8 );	/* Push data on xstack       	*/
	*--stk	 = 0x00;			        /* SP */
	temp_sp  = --stk;                   /* Save stack pointer */
/* When pushing the task pointer we need to push LSB first then MSB	*/
	*stk     = ((INT16U)temp_sp >> 8 );	/* Space for __sp+1 */
	*--stk   = ((INT16U)temp_sp & 0xFF);/* Space for __sp */
	*--stk   = 0x00;			        /* Make R7 00 */
	*--stk   = 0x00;			        /* Make R6 00 */
	*--stk   = 0x00;			        /* Make R5 00 */
	*--stk   = 0x00;			        /* Make R4 00 */
	*--stk   = 0x00;			        /* Make R3 00 */
	*--stk   = 0x00;			        /* Make R2 00 */
	*--stk   = 0x00;			        /* Make R1 00 */
	*--stk   = 0x00;			        /* Make R0 00 */
	*--stk   = 0x00;			        /* Space for dpl */
	*--stk   = 0x00;			        /* Space for dph */
	*--stk   = 0x00;			        /* Push B */
	*--stk   = 0x00;			        /* Push A */
	*--stk   = 0x00;			        /* Push PSW */
	*--stk   = ((INT16U)task >> 8);		/* Push pointer to task         */
	*--stk   = ((INT16U)task & 0xFF);	/* Push pointer to task         */
	*--stk   = 0x12;			        /* Nr of bytes originally on stack that need */
						                /* to be copied to internal stack */
	--stk;					            /* far stackpointer points to next free location */

	return stk;
}

void OSTaskCreateHook(OS_TCB *ptcb)
{
    ptcb = ptcb;
}

void OSTaskDelHook(OS_TCB *ptcb)
{
    ptcb = ptcb;
}

void OSTaskSwHook(void)
{

}

void OSTaskStatHook(void)
{

}

void OSTimeTickHook(void)
{

}
/* === End of File === */
