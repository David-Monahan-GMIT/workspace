/* $Id:os_cpu_c.h, v 1.0
 *
 * Description:
 *	uC/OS-II 80C52 - Processor Dependent Module
 *
 * Author[s]:
 *	Lucas Cruz Martos	<lcm@eresmas.net>
 *
 * Language:
 *	BSO-Tasking ASM51 v5.0r2
 *
 * Reference:
 * 	MicroC/OS-II The Real-Time Kernel. Chapter 8     
 */

#ifndef UCOS52C_H
#define UCOS52C_H

/*
 *                      CONSTANTS
 */
#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE (!FALSE)
#endif


/*
 *                        MACROS
 */
#define  OS_ENTER_CRITICAL()    (EA = 0)
#define  OS_EXIT_CRITICAL()     (EA = 1)
#define  OS_TASK_SW()           OSCtxSw()

/* The following macros must match with ucos51a.asm */
#define  OS_SYS_TIMER   0       /* 0=Timer0, 1=Timer1 */

/*
 *                       DATA TYPES
 */
typedef char            BOOLEAN;    /* Cannot use _bit in structures */
typedef unsigned char   INT8U;
typedef signed   char   INT8S;
typedef unsigned int    INT16U;
typedef signed   int    INT16S;
typedef unsigned long   INT32U;
typedef signed   long   INT32S;

/*
 *                       GLOBAL VARIABLES
 */

/*
 *                       FUNCTION PROTOTYPES
 */

/*
 *                       MISC
 */
#define OS_FAR          /* _large */    /* x86-only */
#define OS_NEAR                         /* x86-only */
#define OS_ROMDATA      _rom            /* const data in ROM */
#define OS_STK     	INT8U           /* Stack is byte-organized */

#endif  /* ndef _UCOS52C_H_ */

/* === End of File === */
