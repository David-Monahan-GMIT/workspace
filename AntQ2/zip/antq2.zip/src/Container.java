
public class Container {
	/**
	 * This is an example of a Javadoc
	 * @param args program parameters
	 * 
	 */
	public static void main(String[] args) {
		
	}

}
